﻿using StockMan.Message.DataAccess;
using StockMan.Message.Task;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace StockMan.Message.Client
{
    public class MainJob
    {
        private IList<ITask> taskList = null;
        public void Excute()
        {
            InitTaskList();
            //轮询task状态，如果任务设定d时间，执行，修改状态为运行中
            
            //如果任务状态为运行中，不检测
            //检测任务状态是停止的，
            //while (true)
            //{
            //加载所有Task
           
            foreach (var task in taskList)
            {
                //如果状态是计划运行
                if (isCanRun(task.GetCode()))
                {
                    //更新状态
                    new TaskHolder(task).Start();
                }
            }
            Thread.Sleep(3000);
            //}

        }

        private bool isCanRun(string code)
        {
            using (DataAccess.messageEntities entity = new messageEntities())
            {
                var task = entity.mq_task.First(p => p.code == code);
                //运行时间检查
                return true;
            }
        }
        public IList<ITask> InitTaskList()
        {
            this.taskList = new List<ITask>();
            IList<mq_task> list = getTaskList();
            foreach (var task in list)
            {
                //反射构建Task实例
                var path = AppDomain.CurrentDomain.BaseDirectory + "taskdll\\" + task.assembly;
                //var tempPath = AppDomain.CurrentDomain.BaseDirectory + "temp\\";
                //if (!Directory.Exists(tempPath))
                //{
                //    Directory.CreateDirectory(tempPath);
                //}
                //File.Copy(path, tempPath + task.assembly,true);
                //ITask taskInstance = Activator.CreateInstanceFrom(tempPath + task.assembly, task.type).Unwrap() as ITask;
                byte[] assemblyBuf = File.ReadAllBytes(path);
                Assembly assembly = Assembly.Load(assemblyBuf);
                ITask taskInstance = assembly.CreateInstance(task.type) as ITask;
                if (taskInstance != null)
                {
                    this.taskList.Add(taskInstance);
                    this.Log().Info("构建消息处理服务：" + task.type);
                }
            }
            return this.taskList;
        }
        private IList<mq_task> getTaskList()
        {
            using (DataAccess.messageEntities entity = new messageEntities())
            {
                return entity.mq_task.Where(p => p.status == 0).ToList();
            }
        }

    }

}
