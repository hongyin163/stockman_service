﻿using StockMan.Message.DataAccess;
using StockMan.Message.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using thread = System.Threading.Tasks;

namespace StockMan.Message.Task
{
    /// <summary>
    /// 负责管理Task
    /// </summary>
    public class TaskHolder
    {
        private ITask task;
        private MessageClient client = null;
        public TaskHolder(ITask task)
        {
            this.client = new MessageClient();
            this.task = task;
        }

        public void Start()
        {
            //开线程
            //thread.Task.Factory.StartNew(buildMessage);
            thread.Task.Factory.StartNew(handleMessage);
        }

        private void buildMessage()
        {
            this.Log().Info("构造消息开始");
            while (true)
            {
                IList<IMessage> msgList = this.task.GetMessage<IMessage>();

                IList<TaskMessage> taskMsgList = msgList.Select(p => new TaskMessage
                {
                    code = "",
                    task_code = this.task.GetCode(),
                    values = Newtonsoft.Json.JsonConvert.SerializeObject(p),
                    description=p.Description
                }).ToList();
                if (msgList.Count == 0)
                    break;

                save(msgList);
                this.Log().Info("保存消息" + msgList.Count + "条");
                Thread.Sleep(100);
            }
        }

        private void save(IList<TaskMessage> msgList)
        {
            //持久化消息，初始化消息状态，未处理
            using (var entity = new messageEntities())
            {
                foreach (var msg in msgList)
                {
                    entity.mq_message.Add(new mq_message
                    {
                        code = msg.code,
                        createtime = DateTime.Now,
                        task_code = msg.task_code,
                        values = msg.values,
                        status = (int)MessageStatus.UnHandle,
                        updatetime = null
                    });
                }
                entity.SaveChanges();
            }
        }
        public void handleMessage()
        {
            this.Log().Info("处理消息开始");
            //没有可用消息时重试的次数，如果超过次数仍没有消息，结束任务
            int retryTotal = 20;
            int retryCount = 0;
            while (true)
            {
                //从数据库获取消息，发送消息，修改状态
                IList<TaskMessage> list = getMessage();
                if (list.Count == 0)
                {
                    this.Log().Info("消息处理完成，等待:" + retryCount * 500);
                    Thread.Sleep(retryCount++ * 500);

                    if (retryCount <= retryTotal)
                        continue;
                    else
                    {
                        this.Log().Info("消息处理全部结束！");
                        break;
                    }
                }
                foreach (var msg in list)
                {
                    this.sendMessage(msg);
                    //更新状态
                    this.updateMessageStatus(msg);

                    this.Log().Info("发送消息:" + msg.code);
                }

                Thread.Sleep(300);
            }

        }

        private void updateMessageStatus(TaskMessage msg)
        {
            using (var entity = new messageEntities())
            {
                var m = entity.mq_message.FirstOrDefault(p => p.code == msg.code);
                if (m != null)
                {
                    m.status = (int)MessageStatus.Wait;
                    m.updatetime = DateTime.Now;
                    entity.SaveChanges();
                }
            }
        }

        private IList<TaskMessage> getMessage()
        {
            using (var entity = new messageEntities())
            {
                var code = this.task.GetCode();
                return entity.mq_message
                    .Where(p => p.task_code == code && (p.status == (int)MessageStatus.UnHandle || p.status == (int)MessageStatus.Retry))
                    .Select(p => new TaskMessage
                    {
                        code = p.code,
                        task_code = p.task_code,
                        values = p.values,
                        description = ""
                    }).ToList();
            }
        }
        private void sendMessage(TaskMessage message)
        {
            this.client.Send(message);
        }
    }
}
