﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetMQ;
using System.Threading;
using System.IO;
using StockMan.Message.Model;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;
namespace StockMan.Message.Client
{
    class Program
    {
        static void Main(string[] args)
        {

            using (NetMQ.NetMQContext context = NetMQContext.Create())
            using (var requester = context.CreateSocket(NetMQ.zmq.ZmqSocketType.Pub))
            {
                requester.Bind("tcp://127.0.0.1:5561");

                while (true)
                {
                    string cmd = Console.ReadLine();
                    NetMQMessage msg = buildMessage(cmd);
                    requester.SendMessage(msg);
                }
            }


        }

        private static NetMQMessage buildMessage(string cmdText)
        {
          
            //target command -p aaa -f dddd -d  
            var cmds = cmdText.Split('-');
            var mainCmd = cmds[0].Trim().Split(' ');
            var target = mainCmd[0];
            var command = mainCmd[1];


            CmdMessage cmd = new CmdMessage()
            {
                target = target,
                command = command
            };

            for (int i = 1; i < cmds.Length; i++)
            {
                var p = cmds[i].Split(' ');
                cmd.Put(p[0], p[1]);
            }
            if (cmd.command == "upload")
            {
                var path = AppDomain.CurrentDomain.BaseDirectory + "taskdll\\";
                string[] files = Directory.GetFiles(path);
                foreach (var file in files)
                {
                    if (File.Exists(file))
                    {
                        byte[] fileData = File.ReadAllBytes(file);
                        cmd.PutAttachment(Path.GetFileName(file), fileData);
                    }
                }
            }
         
            MemoryStream ms = new MemoryStream();
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(ms, cmd);
            byte[] data = ms.ToArray();
            ms.Close();

            //订阅标识
            NetMQMessage msg = new NetMQMessage();
            msg.Append(new NetMQFrame(target));
            msg.Append(new NetMQFrame(data));

            return msg;
        }

        private static void push()
        {
            using (NetMQ.NetMQContext context = NetMQContext.Create())
            using (var requester = context.CreateSocket(NetMQ.zmq.ZmqSocketType.Pub))
            {
                requester.Bind("tcp://127.0.0.1:5561");

                for (int n = 0; n < 100; ++n)
                {
                    requester.Send("Hello" + n);

                    //var reply = requester.ReceiveString();
                    Console.WriteLine("Hello");
                    //Thread.Sleep(100);
                    //Console.WriteLine("Hello {0}!", reply);
                }
            }
        }
    }
}
