﻿using StockMan.Message.DataAccess;
using StockMan.Message.Model;
using StockMan.Message.Task;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace StockMan.Message.Worker
{
    public class Worker
    {
        Dictionary<string, ITask> taskList = new Dictionary<string, ITask>();
        /// <summary>
        /// 初始化Task列表
        /// </summary>
        public void InitTaskList()
        {
            taskList = new Dictionary<string, ITask>();
            IList<mq_task> list = getTaskList();
            foreach (var task in list)
            {

                //反射构建Task实例
                var path = AppDomain.CurrentDomain.BaseDirectory + "taskdll\\" + task.assembly;
                //var tempPath = AppDomain.CurrentDomain.BaseDirectory + "temp\\";
                //if (!Directory.Exists(tempPath))
                //{
                //    Directory.CreateDirectory(tempPath);
                //}
                //File.Copy(path, tempPath + task.assembly, true);
                ////Assembly assebly = Assembly.LoadFile(path);
                ////ITask taskInstance = assebly.CreateInstance(task.type) as ITask;
                //ITask taskInstance = Activator.CreateInstanceFrom(tempPath + task.assembly, task.type).Unwrap() as ITask;

                byte[] assemblyBuf = File.ReadAllBytes(path);
                Assembly assembly = Assembly.Load(assemblyBuf);
                ITask taskInstance = assembly.CreateInstance(task.type) as ITask;
                if (taskInstance != null)
                {
                    this.taskList[task.code] = taskInstance;
                    this.Log().Info("构建消息处理服务：" + task.type);
                }
            }
        }
        private void listener_onError(string obj)
        {
            this.Log().Error(obj);
        }

        private IList<mq_task> getTaskList()
        {
            using (DataAccess.messageEntities entity = new messageEntities())
            {
                return entity.mq_task.Where(p => p.status == 1).ToList();
            }
        }

        public void HandleMessage(TaskMessage msg)
        {
            if (!this.taskList.ContainsKey(msg.task_code))
            {
                this.Log().Error("未找到消息处理服务:task_code:" + msg.task_code);
                return;
            }
            var task = this.taskList[msg.task_code];
            if (task == null)
            {
                this.Log().Error("消息处理服务初始化错误:task_code:" + msg.task_code);
                return;
            }

            try
            {
                this.Log().Info(string.Format("开始处理消息：code:{0},description:{1}",msg.code,msg.description));
                updateMessageStatus(msg, MessageStatus.Running);
                task.Excute(msg);
                updateMessageStatus(msg, MessageStatus.Success);
                this.Log().Info(string.Format("消息处理成功：code:{0},description:{1}", msg.code, msg.description));
            }
            catch (Exception ex)
            {
                updateMessageStatus(msg, MessageStatus.Failed);
                this.Log().Error(string.Format("消息处理失败：code:{0},description:{1},Exception:{2}", msg.code, msg.description,ex.Message));
            }
        }
        MessageListener worklistener = null;
        ControlListener controlListener = null;
        Thread workThread = null;
        Thread controlThread = null;
        public void Start()
        {
            setartControlLister();
            startMessageListener();
        }
        private void setartControlLister()
        {
            this.controlThread = new Thread(() =>
            {
                if (controlListener != null) { controlListener.Dispose(); }
                controlListener = new ControlListener();
                {
                    controlListener.onReceive += this.HandleControlMessage;
                    controlListener.onError += listener_onError;
                    controlListener.connect();
                }
            });
            this.controlThread.Start();

        }
        private void startMessageListener()
        {
            this.workThread = new Thread(() =>
            {
                if (worklistener != null) { worklistener.Dispose(); }
                worklistener = new MessageListener();
                worklistener.onReceive += this.HandleMessage;
                worklistener.onError += listener_onError;
                worklistener.connect();
            });
            this.workThread.Start();

        }
        private void HandleControlMessage(CmdMessage cmdMsg)
        {
            var cmd = cmdMsg.command;
            if (cmd == "reload")
            {
                this.Log().Info("断开连接");
                this.worklistener.Pause();
                //this.worklistener.Close();
                //this.workThread.Interrupt();
                this.Log().Info("重新初始化服务列表");
                this.InitTaskList();
                this.Log().Info("重启连接");
                //this.workThread.Start();
                //this.startMessageListener();
                this.worklistener.Resume();
            }
            else if (cmd == "pause")
            {
                this.Log().Info("暂停");
                this.worklistener.Pause();
            }
            else if (cmd == "resume")
            {
                this.Log().Info("恢复");
                this.worklistener.Resume();
            }
            else if (cmd == "upload")
            {
                this.Log().Info("接收任务程序集");
                var path = AppDomain.CurrentDomain.BaseDirectory + "taskdll\\";
                var files = cmdMsg.attachment;
                foreach (var name in files.Keys)
                {
                    if (files[name] == null)
                        continue;
                    using (FileStream fs = new FileStream(path + name, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite, 1024))
                    {
                        fs.Write(files[name], 0, files[name].Length);
                        fs.Close();
                    }
                    this.Log().Info("保存" + name);
                }

            }

        }

        private void updateMessageStatus(TaskMessage msg, MessageStatus status)
        {
            using (var entity = new messageEntities())
            {
                var m = entity.mq_message.FirstOrDefault(p => p.code == msg.code);
                if (m != null)
                {
                    m.status = (int)status;
                    entity.SaveChanges();
                }
            }
        }
    }
}
